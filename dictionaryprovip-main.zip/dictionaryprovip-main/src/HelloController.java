package com.example.midterm;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController  {

//    @FXML
//    private Button btnDelete;
//
//    @FXML
//    private Button btnInsert;
//
//    @FXML
//    private Button btnModify;
//
//    @FXML
//    private Button btnOffline;
//
//    @FXML
//    private Button btnOnline;
//
//    @FXML
//    private Button btnPara;
//
//    @FXML
//    private Label hiddenMenu;
//
//    @FXML
//    private ImageView imageDelete;
//
//    @FXML
//    private ImageView imageInsert;
//
//    @FXML
//    private ImageView imageModify;
//
//    @FXML
//    private ImageView imageIcon;
//
//    @FXML
//    private ImageView imageOffline;
//
//    @FXML
//    private ImageView imageOnline;
//
//    @FXML
//    private ImageView imagePara;
//
//    @FXML
//    private ImageView imageIconBack;
//
//    @FXML
//    private Label showMenu;
//
//    @FXML
//    private AnchorPane slider;
//
//
//    Image offline = new Image(new File("src/main/java/image/icons8-offline-100.png").toURI().toString());
//    Image online = new Image(new File("src/main/java/image/icons8-online-100.png").toURI().toString());
//    Image modify = new Image(new File("src/main/java/image/3082134-200.jpg").toURI().toString());
//    Image delete = new Image(new File("src/main/java/image/delete+24px-131985190578721347.png").toURI().toString());
//    Image insert = new Image(new File("src/main/java/image/icons8-add-96.png").toURI().toString());
//    Image para = new Image(new File("src/main/java/image/paragraph+alphabet-1324760608295968454.png").toURI().toString());
//    Image menuIcon = new Image(new File("src/main/java/image/icons8-menu-240.png").toURI().toString());
//
//
//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle) {
//        imageDelete.setImage(delete);
//        imageInsert.setImage(insert);
//        imageModify.setImage(modify);
//        imageOffline.setImage(offline);
//        imageOnline.setImage(online);
//        imagePara.setImage(para);
//        imageIcon.setImage(menuIcon);
//        imageIconBack.setImage(menuIcon);
//
//        slider.setTranslateX(0);
//        showMenu.setOnMouseClicked(event -> {
//            TranslateTransition slide = new TranslateTransition();
//            slide.setDuration(Duration.seconds(0.3));
//            slide.setNode(slider);
//
//            slide.setToX(-170);
//            slide.play();
//
//            slider.setTranslateX(0);
//
//            slide.setOnFinished((ActionEvent e)-> {
//                showMenu.setVisible(false);
//                hiddenMenu.setVisible(true);
//            });
//        });
//
//        hiddenMenu.setOnMouseClicked(event -> {
//            TranslateTransition slide = new TranslateTransition();
//            slide.setDuration(Duration.seconds(0.3));
//            slide.setNode(slider);
//
//            slide.setToX(0);
//            slide.play();
//
//            slider.setTranslateX(-170);
//
//            slide.setOnFinished((ActionEvent e)-> {
//                showMenu.setVisible(true);
//                hiddenMenu.setVisible(false);
//            });
//        });
//    }
}
