package uet.oop.bomberman.tile;

import javafx.scene.image.Image;

public class Tile {
    public boolean collision = false;
    public boolean levelUp = false;
    public boolean item = false;
    public Image img;
}
